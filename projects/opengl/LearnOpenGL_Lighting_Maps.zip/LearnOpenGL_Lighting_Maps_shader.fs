#version 330 core
out vec4 FragColor;

in vec3 vsColor;
in vec2 vsTexCoord;

in vec3 vsFragPos;
in vec3 vsNormal;

// uniforms for lighting
uniform vec3 viewPos;

// rendering type
uniform int renderingType;
uniform int objectType;

// light source properties
struct Light {
    vec3 position;

    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
};

struct Material {
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    vec3 shinyNess;
};

struct MaterialTexture {
    sampler2D texture;
    sampler2D ambient;
    sampler2D diffuse;
    sampler2D specular;
    sampler2D normalMap;
};

uniform Light light;
uniform Material material;
uniform MaterialTexture mtrlTex1;
uniform MaterialTexture mtrlTex2;

void calc_ambient( out vec3 ambient_out, vec3 light, vec3 material ){
    ambient_out = light * material;
}

void calc_diffuse( out vec3 diffuse_out, out vec3 lightDir_out, out float diff_out, vec3 normal, vec3 pixel_pos, vec3 light_pos, vec3 light, vec3 material ){
    lightDir_out = normalize( light_pos - pixel_pos );
    diff_out     = max( dot( normal, lightDir_out ), 0.0 );
    diffuse_out  = light * diff_out * material;
}

void calc_specular( out vec3 specular_out, vec3 normal, vec3 pixel_pos, vec3 view_pos, vec3 light_dir, vec3 light, vec3 material, float shiny ){
    vec3 viewDir        = normalize( view_pos - pixel_pos );
    vec3 reflectDir     = reflect( -light_dir, normal );
    float viewedReflect = max( dot( viewDir, reflectDir ), 0.0 );
    float spec          = pow( viewedReflect, shiny );
    specular_out        = light * spec * material;
}

void calc_tbn_matrix( out mat3 tbn, vec3 normal, vec3 pixel_pos, vec2 pixel_texcoord ){
    // Calculate derivatives
    vec3 pos_dx  = dFdx(pixel_pos);
    vec3 pos_dy  = dFdy(pixel_pos);
    vec2 texC_dx = dFdx(pixel_texcoord);
    vec2 texC_dy = dFdy(pixel_texcoord);

    // Calculate tangent and bitangent
    vec3 tangent   = normalize(texC_dy.y * pos_dx - texC_dx.y * pos_dy);
    vec3 bitangent = normalize(texC_dx.x * pos_dy - texC_dy.x * pos_dx);

    // Construct TBN matrix
    tbn = mat3( tangent, bitangent, normal ); // normal interpolated vertex normal (after normalization)
}

void main(){
    if( objectType == 0 ){
        FragColor = vec4( light.diffuse, 1.0 );
    } else {
        // First implementation of the example using only the first texture
        if( renderingType < 2 ){
            FragColor = texture( mtrlTex1.texture, vsTexCoord );
        } else if( renderingType == 2 ){
            // Second implementation of the example using texture and color inputs
            FragColor = texture( mtrlTex1.texture, vsTexCoord ) * vec4( vsColor, 1.0 );
        } else if( renderingType == 3 ){
            // Third implmentation of the example linearly interpolating between both textures
            FragColor = mix( texture( mtrlTex1.texture, vsTexCoord ), texture( mtrlTex2.texture, vsTexCoord ), 0.5 );
        } else if( renderingType == 4 ){
            // Fourth implmentation of the example with colored object defined by vec3 and a light
            FragColor = vec4( light.diffuse * material.diffuse, 1.0 );
        } else if( renderingType == 5 ){
            // Fifth implementation of the example with only ambient lighting
            vec3 ambient;
            calc_ambient( ambient, light.ambient, material.ambient );
            FragColor    = vec4( ambient, 1.0 );
        } else if( renderingType == 6 ){
            // Sixth implementation of the example with ambient and diffuse lighting
            vec3 ambient, diffuse, lightDir;
            float diff;
            calc_ambient( ambient, light.ambient, material.ambient );
            calc_diffuse( diffuse, lightDir, diff, normalize(vsNormal), vsFragPos, light.position, light.diffuse, material.diffuse );
            FragColor     = vec4( ( ambient + diffuse ), 1.0 );
        } else if( renderingType == 7 ){
            // Seventh implementation of the example with only ambient, diffuse, and specular lighting (Phong Lighting)
            vec3 ambient, diffuse, specular, lightDir;
            float diff;
            vec3 normal_norm = normalize(vsNormal);
            calc_ambient( ambient, light.ambient, material.ambient );
            calc_diffuse( diffuse, lightDir, diff, normal_norm, vsFragPos, light.position, light.diffuse, material.diffuse );
            calc_specular( specular, normal_norm, vsFragPos, viewPos, lightDir, light.specular, material.specular, material.shinyNess.x );
            FragColor = vec4( ( ambient + diffuse + specular ), 1.0 );
        } else if( renderingType == 8 ){
            // Eighth implementation of the example with only ambient, diffuse, specular lighting (Phong Lighting), and textures
            // blend all the textures
            vec3 ambTex  = mix( texture( mtrlTex1.ambient,  vsTexCoord ).rgb, texture( mtrlTex2.ambient,  vsTexCoord ).rgb, 0.5 );
            vec3 diffTex = mix( texture( mtrlTex1.diffuse,  vsTexCoord ).rgb, texture( mtrlTex2.diffuse,  vsTexCoord ).rgb, 0.5 );
            vec3 specTex = mix( texture( mtrlTex1.specular, vsTexCoord ).rgb, texture( mtrlTex2.specular, vsTexCoord ).rgb, 0.5 );

            vec3 ambient, diffuse, specular, lightDir;
            float diff;
            vec3 normal_norm = normalize(vsNormal);
            calc_ambient( ambient, light.ambient, (material.ambient * ambTex) );
            calc_diffuse( diffuse, lightDir, diff, normal_norm, vsFragPos, light.position, light.diffuse, (material.diffuse * diffTex) );
            calc_specular( specular, normal_norm, vsFragPos, viewPos, lightDir, light.specular, (material.specular * specTex), material.shinyNess.x );
                
            FragColor = vec4( ( ambient + diffuse + specular ), 1.0 );// * texColor;
        } else if( renderingType == 9 ){
            // Nineth implementation of the example with only ambient, diffuse, specular lighting (Phong Lighting), texture, and normal maps
            // Sample normal map, get normal vector, then normalize and remap (* 2 - 1)
            vec3 normalMapNormal1 = normalize( texture( mtrlTex1.normalMap, vsTexCoord ).rgb * 2.0 - 1.0 );

            // Construct TBN matrix
            mat3 tbn;
            calc_tbn_matrix( tbn, vsNormal, vsFragPos, vsTexCoord );

            // Transform the normal
            vec3 worldNormal1 = normalize( tbn * normalMapNormal1 );

            vec3 ambTex  = texture( mtrlTex1.ambient,  vsTexCoord ).rgb;
            vec3 diffTex = texture( mtrlTex1.diffuse,  vsTexCoord ).rgb;
            vec3 specTex = texture( mtrlTex1.specular, vsTexCoord ).rgb;

            vec3 ambient, diffuse, specular, lightDir;
            float diff;
            calc_ambient( ambient, light.ambient, (material.ambient * ambTex) );
            calc_diffuse( diffuse, lightDir, diff, worldNormal1, vsFragPos, light.position, light.diffuse, (material.diffuse * diffTex) );
            calc_specular( specular, worldNormal1, vsFragPos, viewPos, lightDir, light.specular, (material.specular * specTex), material.shinyNess.x );
                
            FragColor = vec4( ( ambient + diffuse + specular ), 1.0 );// * texColor;
        } else if( renderingType == 10 ){
            // Tenth implementation of the example with only ambient, diffuse, specular lighting (Phong Lighting), texture, and normal maps
            // This implementation (vs 11 below) takes two textures, blends them together, and then uses blended normals and textures
            // Sample normal map, get normal vector, then normalize and remap (* 2 - 1)
            vec3 normalMapNormal1 = normalize( texture( mtrlTex1.normalMap, vsTexCoord ).rgb * 2.0 - 1.0 );
            vec3 normalMapNormal2 = normalize( texture( mtrlTex2.normalMap, vsTexCoord ).rgb * 2.0 - 1.0 );

            // Construct TBN matrix
            mat3 tbn;
            calc_tbn_matrix( tbn, vsNormal, vsFragPos, vsTexCoord );

            // Transform the normal
            vec3 worldNormal1 = normalize( tbn * normalMapNormal1 );
            vec3 worldNormal2 = normalize( tbn * normalMapNormal2 );

            vec3 pixelNormal = normalize( mix( worldNormal1, worldNormal2, 0.5 ) );

            // blending two textures together and using an average worldNormal based on both at the pixel (pixelNormal)
            vec3 ambTex  = mix( texture( mtrlTex1.ambient,  vsTexCoord ).rgb, texture( mtrlTex2.ambient,  vsTexCoord ).rgb, 0.5 );
            vec3 diffTex = mix( texture( mtrlTex1.diffuse,  vsTexCoord ).rgb, texture( mtrlTex2.diffuse,  vsTexCoord ).rgb, 0.5 );
            vec3 specTex = mix( texture( mtrlTex1.specular, vsTexCoord ).rgb, texture( mtrlTex2.specular, vsTexCoord ).rgb, 0.5 );

            vec3 ambient, diffuse, specular, lightDir;
            float diff;
            calc_ambient( ambient, light.ambient, (material.ambient * ambTex) );
            calc_diffuse( diffuse, lightDir, diff, pixelNormal, vsFragPos, light.position, light.diffuse, (material.diffuse * diffTex) );
            calc_specular( specular, pixelNormal, vsFragPos, viewPos, lightDir, light.specular, (material.specular * specTex), material.shinyNess.x );
                
            FragColor = vec4( ( ambient + diffuse + specular ), 1.0 );
        } else if( renderingType == 11 ){
            // Eleventh implementation of the example with only ambient, diffuse, specular lighting (Phong Lighting), texture, and normal maps
            // This implementation handles diffuse and specular seperately for each texture
            // Sample normal map, get normal vector, then normalize and remap (* 2 - 1)
            vec3 normalMapNormal1 = normalize( texture( mtrlTex1.normalMap, vsTexCoord ).rgb * 2.0 - 1.0 );
            vec3 normalMapNormal2 = normalize( texture( mtrlTex2.normalMap, vsTexCoord ).rgb * 2.0 - 1.0 );

            // Construct TBN matrix
            mat3 tbn;
            calc_tbn_matrix( tbn, vsNormal, vsFragPos, vsTexCoord );

            // Transform the normal
            vec3 worldNormal1 = normalize( tbn * normalMapNormal1 );
            vec3 worldNormal2 = normalize( tbn * normalMapNormal2 );

            // blend the textures for ambient, diffuse and specular handle each texture independently
            vec3 ambTex  = mix( texture( mtrlTex1.ambient,  vsTexCoord ).rgb, texture( mtrlTex2.ambient,  vsTexCoord ).rgb, 0.5 );
            vec3 diffTex1 = texture( mtrlTex1.diffuse, vsTexCoord ).rgb;
            vec3 diffTex2 = texture( mtrlTex2.diffuse, vsTexCoord ).rgb;
            vec3 specTex1 = texture( mtrlTex1.specular, vsTexCoord ).rgb;
            vec3 specTex2 = texture( mtrlTex2.specular, vsTexCoord ).rgb;

            vec3 ambient, diffuse1, diffuse2, specular1, specular2, lightDir1, lightDir2;
            float diff1, diff2;
            
            calc_ambient( ambient, light.ambient, (material.ambient * ambTex) );
            calc_diffuse( diffuse1, lightDir1, diff1, worldNormal1, vsFragPos, light.position, light.diffuse, (material.diffuse * diffTex1) );
            calc_diffuse( diffuse2, lightDir2, diff2, worldNormal2, vsFragPos, light.position, light.diffuse, (material.diffuse * diffTex2) );
            calc_specular( specular1, worldNormal1, vsFragPos, viewPos, lightDir1, light.specular, (material.specular * specTex1), material.shinyNess.x );
            calc_specular( specular2, worldNormal2, vsFragPos, viewPos, lightDir2, light.specular, (material.specular * specTex2), material.shinyNess.x );

            FragColor = vec4( ( ambient + mix( diffuse1, diffuse2, 0.5 ) + mix( specular1, specular2, 0.5 ) ), 1.0 );
        }
    }
}