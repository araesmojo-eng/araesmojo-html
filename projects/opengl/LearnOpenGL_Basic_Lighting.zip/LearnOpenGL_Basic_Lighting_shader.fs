#version 330 core
out vec4 FragColor;

in vec3 vsColor;
in vec2 vsTexCoord;

in vec3 vsFragPos;
in vec3 vsNormal;

// texture samplers
uniform sampler2D texture1;
uniform sampler2D texture2;

// uniforms for lighting
uniform vec3 lightPos;
uniform vec3 viewPos;
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 ambientLightColor;

// rendering type
uniform int renderingType;
uniform int objectType;

// variable properties
uniform float ambientIntensity;
uniform float diffuseIntensity;
uniform float specularIntensity;
uniform float specularShinyness;

void main(){
    if( objectType == 0 ){
        FragColor = vec4( lightColor, 1.0 );
    } else {
        // First implementation of the example using only the first texture
        if( renderingType < 2 ){
            FragColor = texture( texture1, vsTexCoord );
        } else if( renderingType == 2 ){
            // Second implementation of the example using texture and color inputs
            FragColor = texture( texture1, vsTexCoord ) * vec4( vsColor, 1.0 );
        } else if( renderingType == 3 ){
            // Third implmentation of the example linearly interpolating between both textures
            FragColor = mix( texture( texture1, vsTexCoord ), texture( texture2, vsTexCoord ), 0.5 );
        } else if( renderingType == 4 ){
            // Fourth implmentation of the example with colored object defined by vec3 and a light
            FragColor = vec4( lightColor * objectColor, 1.0 );
        } else if( renderingType == 5 ){
            // Fifth implementation of the example with only ambient lighting
            // ambient
            vec3 ambient = ambientIntensity * ambientLightColor;
            FragColor    = vec4( ambient * objectColor, 1.0 );
        } else if( renderingType == 6 ){
            // Sixth implementation of the example with ambient and diffuse lighting
            // ambient
            vec3 ambient = ambientIntensity * ambientLightColor;
            
            // diffuse 
            vec3 norm     = normalize( vsNormal );
            vec3 lightDir = normalize( lightPos - vsFragPos );
            float diff    = max( dot( norm, lightDir ), 0.0 );
            vec3 diffuse  = diffuseIntensity * diff * lightColor;
            FragColor     = vec4( ( ambient + diffuse ) * objectColor, 1.0 );
        } else {
            // Seventh implementation of the example with only ambient, diffuse, and specular lighting (Phong Lighting)
            // ambient
            vec3 ambient = ambientIntensity * ambientLightColor;
            
            // diffuse
            vec3 norm     = normalize(vsNormal);
            vec3 lightDir = normalize( lightPos - vsFragPos );
            float diff    = max( dot( norm, lightDir ), 0.0 );
            vec3 diffuse  = diffuseIntensity * diff * lightColor;
            
            // specular
            vec3 viewDir    = normalize( viewPos - vsFragPos );
            vec3 reflectDir = reflect( -lightDir, norm );  
            float spec      = pow( max( dot( viewDir, reflectDir ), 0.0 ), specularShinyness );
            vec3 specular   = specularIntensity * spec * lightColor;  
                
            vec3 result = ( ambient + diffuse + specular ) * objectColor;
            FragColor = vec4( result, 1.0 );
        }
    }
}