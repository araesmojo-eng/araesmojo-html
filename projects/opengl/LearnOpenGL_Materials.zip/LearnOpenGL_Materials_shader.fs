#version 330 core
out vec4 FragColor;

in vec3 vsColor;
in vec2 vsTexCoord;

in vec3 vsFragPos;
in vec3 vsNormal;

// texture samplers
uniform sampler2D texture1;
uniform sampler2D texture2;
uniform sampler2D normalMap1;
uniform sampler2D normalMap2;

// uniforms for lighting
uniform vec3 viewPos;

// rendering type
uniform int renderingType;
uniform int objectType;

// light source properties
struct Light {
    vec3 position;

    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
};

struct Material {
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    vec3 shinyNess;
};

uniform Light light;
uniform Material material;

void main(){
    if( objectType == 0 ){
        FragColor = vec4( light.diffuse, 1.0 );
    } else {
        // First implementation of the example using only the first texture
        if( renderingType < 2 ){
            FragColor = texture( texture1, vsTexCoord );
        } else if( renderingType == 2 ){
            // Second implementation of the example using texture and color inputs
            FragColor = texture( texture1, vsTexCoord ) * vec4( vsColor, 1.0 );
        } else if( renderingType == 3 ){
            // Third implmentation of the example linearly interpolating between both textures
            FragColor = mix( texture( texture1, vsTexCoord ), texture( texture2, vsTexCoord ), 0.5 );
        } else if( renderingType == 4 ){
            // Fourth implmentation of the example with colored object defined by vec3 and a light
            FragColor = vec4( light.diffuse * material.diffuse, 1.0 );
        } else if( renderingType == 5 ){
            // Fifth implementation of the example with only ambient lighting
            // ambient
            vec3 ambient = light.ambient * material.ambient;
            FragColor    = vec4( ambient, 1.0 );
        } else if( renderingType == 6 ){
            // Sixth implementation of the example with ambient and diffuse lighting
            // ambient
            vec3 ambient = light.ambient * material.ambient;
            
            // diffuse 
            vec3 norm     = normalize(vsNormal);
            vec3 lightDir = normalize( light.position - vsFragPos );
            float diff    = max( dot( norm, lightDir ), 0.0 );
            vec3 diffuse  = light.diffuse * (diff * material.diffuse);
            FragColor     = vec4( ( ambient + diffuse ), 1.0 );
        } else if( renderingType == 7 ){
            // Seventh implementation of the example with only ambient, diffuse, and specular lighting (Phong Lighting)
            // ambient
            vec3 ambient = light.ambient * material.ambient;
            
            // diffuse
            vec3 norm     = normalize(vsNormal);
            vec3 lightDir = normalize( light.position - vsFragPos );
            float diff    = max( dot( norm, lightDir ), 0.0 );
            vec3 diffuse  = light.diffuse * (diff * material.diffuse);
            
            // specular
            vec3 viewDir        = normalize( viewPos - vsFragPos );
            vec3 reflectDir     = reflect( -lightDir, norm );
            float viewedReflect = max( dot( viewDir, reflectDir ), 0.0 );

            // experimenting with having specular have different reflections for different colors
            vec3 spec           = pow( vec3( viewedReflect, viewedReflect, viewedReflect ), material.shinyNess );
            vec3 specular       = light.specular * (spec * material.specular);
                
            FragColor = vec4( ( ambient + diffuse + specular ), 1.0 );
        } else if( renderingType == 8 ){
            // Eighth implementation of the example with only ambient, diffuse, specular lighting (Phong Lighting), and textures
            // ambient
            vec3 ambient = light.ambient * material.ambient;
            
            // diffuse
            vec3 norm     = normalize(vsNormal);
            vec3 lightDir = normalize( light.position - vsFragPos );
            float diff    = max( dot( norm, lightDir ), 0.0 );
            vec3 diffuse  = light.diffuse * (diff * material.diffuse);
            
            // specular
            vec3 viewDir        = normalize( viewPos - vsFragPos );
            vec3 reflectDir     = reflect( -lightDir, norm );
            float viewedReflect = max( dot( viewDir, reflectDir ), 0.0 );

            // experimenting with having specular have different reflections for different colors
            vec3 spec           = pow( vec3( viewedReflect, viewedReflect, viewedReflect ), material.shinyNess );
            vec3 specular       = light.specular * (spec * material.specular);

            // interpolating between both textures
            vec4 texColor = mix( texture( texture1, vsTexCoord ), texture( texture2, vsTexCoord ), 0.5 );
                
            FragColor = vec4( ( ambient + diffuse + specular ), 1.0 ) * texColor;
        } else {
            // Nineth implementation of the example with only ambient, diffuse, specular lighting (Phong Lighting), texture, and normal maps
            // Sample normal map and get normal vector
            vec3 normalMapNormal1 = texture( normalMap1, vsTexCoord ).rgb;
            normalMapNormal1      = normalize( normalMapNormal1 * 2.0 - 1.0 ); // Remap and normalize
            vec3 normalMapNormal2 = texture( normalMap2, vsTexCoord ).rgb;
            normalMapNormal2      = normalize( normalMapNormal2 * 2.0 - 1.0 ); // Remap and normalize

            // Calculate derivatives
            vec3 pos_dx  = dFdx(vsFragPos);
            vec3 pos_dy  = dFdy(vsFragPos);
            vec2 texC_dx = dFdx(vsTexCoord);
            vec2 texC_dy = dFdy(vsTexCoord);

            // Calculate tangent and bitangent
            vec3 tangent = normalize(texC_dy.y * pos_dx - texC_dx.y * pos_dy);
            vec3 bitangent = normalize(texC_dx.x * pos_dy - texC_dy.x * pos_dx);

            // Construct TBN matrix
            mat3 tbn = mat3( tangent, bitangent, vsNormal ); // fragNormal is the interpolated vertex normal

            // Transform the normal
            vec3 worldNormal1 = normalize( tbn * normalMapNormal1 );
            vec3 worldNormal2 = normalize( tbn * normalMapNormal2 );

            vec3 pixelNormal = mix( worldNormal1, worldNormal2, 0.5 );

            // ambient
            vec3 ambient = light.ambient * material.ambient;
            
            // diffuse
            vec3 norm     = normalize( pixelNormal );
            vec3 lightDir = normalize( light.position - vsFragPos );
            float diff    = max( dot( norm, lightDir ), 0.0 );
            vec3 diffuse  = light.diffuse * (diff * material.diffuse);
            
            // specular
            vec3 viewDir        = normalize( viewPos - vsFragPos );
            vec3 reflectDir     = reflect( -lightDir, norm );
            float viewedReflect = max( dot( viewDir, reflectDir ), 0.0 );

            // experimenting with having specular have different reflections for different colors
            vec3 spec           = pow( vec3( viewedReflect, viewedReflect, viewedReflect ), material.shinyNess );
            vec3 specular       = light.specular * (spec * material.specular);

            // interpolating between both textures
            vec4 texColor = mix( texture( texture1, vsTexCoord ), texture( texture2, vsTexCoord ), 0.5 );
                
            FragColor = vec4( ( ambient + diffuse + specular ), 1.0 ) * texColor;
        }
    }
}