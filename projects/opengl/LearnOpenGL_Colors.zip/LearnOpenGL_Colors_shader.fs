#version 330 core
out vec4 FragColor;

in vec3 vertexShaderOutColor;
in vec2 TexCoord;

// texture samplers
uniform sampler2D texture1;
uniform sampler2D texture2;

// uniforms for lighting
uniform vec3 objectColor;
uniform vec3 lightColor;

// rendering type
uniform int renderingType;
uniform int objectType;

void main(){
    if( objectType == 0 ){
        FragColor = vec4( lightColor, 1.0 );
    } else {
        // First implementation of the example using only the first texture
        if( renderingType < 2 ){
            FragColor = texture( texture1, TexCoord );
        } else if( renderingType == 2 ){
            // Second implementation of the example using texture and color inputs
            FragColor = texture( texture1, TexCoord ) * vec4( vertexShaderOutColor, 1.0 );
        } else if( renderingType == 3 ){
            // Third implmentation of the example linearly interpolating between both textures
            FragColor = mix( texture( texture1, TexCoord ), texture( texture2, TexCoord ), 0.5 );
        } else {
            // Fourth implmentation of the example with colored object defined by vec3 and a light
            FragColor = vec4( lightColor * objectColor, 1.0 );
        }
    }
}